/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdint.h>
#include <math.h>

double calculate_dew_point (int16_t temperature, int16_t humidity);

int
main ()
{
  int16_t temperature = 239;
  int16_t humidity = 173;
  int16_t temp_Out = 59;
  int16_t humid_Out = 703;
  double dewpoint_In, dewpoint_Out;

  dewpoint_In = calculate_dew_point (temperature, humidity);
  dewpoint_Out = calculate_dew_point (temp_Out, humid_Out);

  if (dewpoint_Out > dewpoint_In)
    {
      //turn LED_RED;
      printf ("DO NOT Ventilate, close the window");
    }
  else
    {
      //turn LED_GREEN;
      printf ("Ventilate, open the window");
    }
  //double dewpoint_Out = calculate_dew_point(temp_Out, humid_Out);

  //temp_log = log((double) humidity/1000.00);
  //printf("Log %.2lf B:C\n", temp_log);
  return 0;
}

double
calculate_dew_point (int16_t temperature, int16_t humidity)
{
  double temp_, humid_;
  double gamma, dewpoint;
  int16_t int_dewpoint;

  temp_ = (double) temperature / 10.0;
  humid_ = (double) humidity / 10.0;

  printf
    ("Calculating dew point for temperature %d.%d Celcius and humidity %d.%d RH\n",
     temperature / 10, temperature % 10, humidity / 10, humidity % 10);

  gamma = (17.271 * temp_) / (237.7 + temp_) + log (humid_ / 100.0);
  dewpoint = (237.7 * gamma) / (17.271 - gamma);
  printf ("Dew Point %.2lf B:C\n", dewpoint);

  int_dewpoint = (int16_t) (dewpoint * 100);
  printf ("Int dew point %d.%d B:C\n", int_dewpoint / 100,
	  abs (int_dewpoint % 100));

  return dewpoint;
}

 /*
    int convert_double_to_int(double value) {
    return (int16_t) value;
    If the outside dew point is higher than inside, do not vent.
    Otherwise, if the outside temperature is at least 15b, ventilate permanently
    Otherise, ventilate for 20 minutes, then make a break depending on outside temperature: the colder it is, the longer the break.
    }
  */
l
